package com.assignment.sandeep.stockwatch.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.assignment.sandeep.stockwatch.R;
import com.assignment.sandeep.stockwatch.model.StockResponse;

import java.text.DecimalFormat;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class StockAdapter extends RecyclerView.Adapter<StockAdapter.ViewHolder> {
    private List<StockResponse> stockList;
    private ItemCallBacks itemCallBacks;
    private DecimalFormat df = new DecimalFormat("##.##");

    public StockAdapter(List<StockResponse> stockList,ItemCallBacks itemCallBacks) {
        this.stockList = stockList;
        this.itemCallBacks = itemCallBacks;
    }

    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_recycler_stock, parent, false));
    }

    public void setItems(List<StockResponse> stockList){
        this.stockList = stockList;
        notifyDataSetChanged();
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i) {
        final StockResponse stockResponse = stockList.get(i);

        if (Math.abs(stockResponse.getPriceChange()) == stockResponse.getPriceChange()) {
            viewHolder.tvSymbol.setTextColor(viewHolder.tvSymbol.getResources().getColor(R.color.colorGreenDark));
            viewHolder.tvCompanyName.setTextColor(viewHolder.tvCompanyName.getResources().getColor(R.color.colorGreenDark));
            viewHolder.tvPrice.setTextColor(viewHolder.tvPrice.getResources().getColor(R.color.colorGreenDark));
            viewHolder.tvPriceChange.setTextColor(viewHolder.tvPriceChange.getResources().getColor(R.color.colorGreenDark));
            viewHolder.ivChangeImage.setBackgroundResource(R.drawable.icon_up);

        } else {
            viewHolder.tvSymbol.setTextColor(viewHolder.tvSymbol.getResources().getColor(R.color.colorRedDark));
            viewHolder.tvCompanyName.setTextColor(viewHolder.tvCompanyName.getResources().getColor(R.color.colorRedDark));
            viewHolder.tvPrice.setTextColor(viewHolder.tvPrice.getResources().getColor(R.color.colorRedDark));
            viewHolder.tvPriceChange.setTextColor(viewHolder.tvPriceChange.getResources().getColor(R.color.colorRedDark));
            viewHolder.ivChangeImage.setBackgroundResource(R.drawable.icon_down);
        }

        viewHolder.tvSymbol.setText(stockResponse.getStockSymbol());
        viewHolder.tvCompanyName.setText(stockResponse.getCompanyName());
        viewHolder.tvPrice.setText(String.valueOf(stockResponse.getStockPrice()));
        viewHolder.tvPriceChange.setText(df.format(stockResponse.getPriceChange()) + "(" + df.format(stockResponse.getPercentageChange()) + "%)");
        viewHolder.itemView.setOnClickListener(viewHolder);
        viewHolder.itemView.setOnLongClickListener(viewHolder);
    }

    @Override
    public int getItemCount() {
        return stockList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener ,View.OnLongClickListener {
        TextView tvSymbol;
        TextView tvCompanyName;
        TextView tvPrice;
        TextView tvPriceChange;
        ImageView ivChangeImage;

        public ViewHolder(View itemView) {
            super(itemView);
            tvSymbol = itemView.findViewById(R.id.tv_symbol);
            tvCompanyName = itemView.findViewById(R.id.tv_company_name);
            tvPrice = itemView.findViewById(R.id.tv_price);
            tvPriceChange = itemView.findViewById(R.id.tv_price_change);
            ivChangeImage = itemView.findViewById(R.id.iv_change_image);
        }

        @Override
        public void onClick(View v) {
            itemCallBacks.onItemClick(getAdapterPosition());
        }

        @Override
        public boolean onLongClick(View v) {
            itemCallBacks.onLongClick(getAdapterPosition());
            return true;
        }
    }

    interface ItemCallBacks{
        void onItemClick(int position);
        void onLongClick(int position);
    }

}
