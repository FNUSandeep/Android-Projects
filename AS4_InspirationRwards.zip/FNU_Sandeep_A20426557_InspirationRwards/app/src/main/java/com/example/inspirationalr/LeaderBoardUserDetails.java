package com.example.inspirationalr;

import java.io.Serializable;

public class LeaderBoardUserDetails implements Serializable {
}
