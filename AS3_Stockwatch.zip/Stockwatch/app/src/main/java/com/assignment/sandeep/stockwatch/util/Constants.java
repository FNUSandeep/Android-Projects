package com.assignment.sandeep.stockwatch.util;

public interface Constants {
    String MARKET_WATCH_URL = "https://www.marketwatch.com/investing/stock/";
    String STOCK_SYMBOLS_URL = "https://api.iextrading.com/1.0/ref-data/symbols";
    String STOCK_DOWNLOAD_MAIN_URL = "https://cloud.iexapis.com/stable/stock/";
    String STOCK_DOWNLOAD_QUERY_URL = "/quote?token=sk_d87730e079bd4c24a9edbad0433ebcb7";

    String HTTP_CALL_GET = "GET";
}
