package com.example.temperatureconverter;

import androidx.appcompat.app.AppCompatActivity;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

     RadioButton celtoFah;
     RadioButton FahtoCel;
     EditText inputdegree;
     TextView outputdegree;
     TextView inputTemp;
     TextView outputTemp;
     TextView ConversionHistory;
     Button convert;
     Button clear;
     String string="";
     String checkRadioButton = "Fahrenheit to Celsius";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        celtoFah = (RadioButton) findViewById(R.id.CeltoFah);
        FahtoCel = (RadioButton) findViewById(R.id.FahtoCel);
        inputdegree = (EditText) findViewById(R.id.inputDegree);
        outputdegree = (TextView) findViewById(R.id.outputDegree);
        inputTemp = (TextView) findViewById(R.id.inputTemp);
        outputTemp = (TextView) findViewById(R.id.outputTemp);
        ConversionHistory = (TextView) findViewById(R.id.viewHistory);
        convert =(Button) findViewById(R.id.clear);
        ConversionHistory.setMovementMethod(new ScrollingMovementMethod());
    }

    public void selectUnit(View v) {
        checkRadioButton = ((RadioButton) v).getText().toString();
        if(checkRadioButton.trim().equals("Fahrenheit to Celsius")) {
            inputTemp.setText("Fahrenheit Degree");
            outputTemp.setText("Celsius Degree");
        }
        else {
            inputTemp.setText("Celsius Degree");
            outputTemp.setText("Fahrenheit Degree");
        }
        inputdegree.setText("");
        outputdegree.setText("");
    }


    public void onClickClear(View v) {
        string="";
        ConversionHistory.setText(string);
    }
    public void TempConversion (View v){
        Double TempInput = Double.parseDouble(inputdegree.getText().toString());
        System.out.println(TempInput);
        Double res;
        if (celtoFah.isChecked()) {
            if (inputdegree.getText().length() == 0) {
                Toast.makeText(getApplicationContext(), "Please Enter Temperature in Celsius", Toast.LENGTH_SHORT).show();
            } else {
                res = (TempInput * 1.8) + 32;
                outputdegree.setText(String.format("%,.1f", res));
                double a = Double.parseDouble(inputdegree.getText().toString());
                string = "C to F: " + (String.format("%,.1f", a)) + " -> " + (String.format("%,.1f", res)) + "\n" + string;
                ConversionHistory.setText(string);
            }
        }
        if (FahtoCel.isChecked()) {
            if (inputdegree.getText().length() == 0) {
                Toast.makeText(getApplicationContext(), "Please Enter Temperature in Fahrenheit ", Toast.LENGTH_SHORT).show();
            } else {
                res = (TempInput - 32) / 1.8;
                outputdegree.setText(String.format("%,.1f", res));
                double e =  Double.parseDouble(inputdegree.getText().toString());
                string = "F to C: " + (String.format("%,.1f", e)) + " -> " + (String.format("%,.1f", res)) + "\n" + string;
                System.out.println(string);
                ConversionHistory.setText(string);
            }

        }
    }

    protected void onSaveInstanceState(Bundle outState) {

        outState.putString("ConversionHistory", string);
        outState.putString("inputTemp", inputTemp.getText().toString());
        outState.putString("outputTemp", outputTemp.getText().toString());
        outState.putString("inputVal", inputdegree.getText().toString());
        outState.putString("outputVal", outputdegree.getText().toString());
        super.onSaveInstanceState(outState);
    }

    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        // Call super first
        super.onRestoreInstanceState(savedInstanceState);

        string = savedInstanceState.getString("ConversionHistory");
        ConversionHistory.setText(string);
        inputdegree.setText(savedInstanceState.getString("inputVal"));
        outputdegree.setText(savedInstanceState.getString("outputVal"));
        inputTemp.setText(savedInstanceState.getString("inputTemp"));
        outputTemp.setText(savedInstanceState.getString("outputTemp"));
        if(savedInstanceState.getString("inputTemp").toString().equalsIgnoreCase("Celsius Degree")){
            celtoFah.setChecked(true);
            FahtoCel.setChecked(false);
        } else {
            celtoFah.setChecked(false);
            FahtoCel.setChecked(true);
        }
    }


}